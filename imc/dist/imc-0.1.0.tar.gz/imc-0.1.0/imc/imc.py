def calcular_imc(peso,altura):
    imc = peso / (altura ** 2)

    return f"O valor do IMC é: {imc}"